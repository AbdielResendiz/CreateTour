import { HStack, Text, Center, Stack, Box, Image, View, Pressable } from "native-base";
import { Outlet, Link } from "react-router-dom";
import { IconContext } from "react-icons";
import { TiShoppingCart } from "react-icons/ti";
import { useUser } from "../helper/UserContext";
import { useState, useEffect } from "react";
import { useTranslation } from 'react-i18next';
import { animateScroll as scroll } from 'react-scroll';
import MenuHamburger from "../Components/header/MenuHamburger";


const Header = () => {
    const { t } = useTranslation("global");
    const { carrito } = useUser();
    const [carritoCantidad, setCarritoCantidad] = useState(0);
    useEffect(() => {
        let cantidad = carrito.length;
        setCarritoCantidad(cantidad)

    }, [carrito])

    const headerStyle = {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,

        zIndex: 1000, // Ajusta el valor según sea necesario
    };


    const handlePressTurismo = () => {

        const Url = `https://sedeturqroo.gob.mx/siturq/index.php?op=4`;

        // Abre la URL en una nueva pestaña
        window.open(Url, '_blank');
    };



    const linkStyle = {

        textDecoration: "none",


    };

    const CustomLink = ({ to, text }) => {
        const handleClick1 = () => {
            // Al hacer clic en el enlace, desplázate suavemente hacia la parte superior
            scroll.scrollToTop();
        };
        return (
            <Link to={to} style={linkStyle} onClick={handleClick1} >
                <Text p={[1, 1, 2, 2]} borderWidth={1} borderRadius={10} fontFamily={"Avenir"}
                    shadow={3} mx={2} bg={"#eeeeee"} borderColor={"muted.300"}
                    fontSize={"sm"} >
                    {text}</Text>
            </Link>
        );
    };

    const handleClick = () => {
        // Al hacer clic en el enlace, desplázate suavemente hacia la parte superior
        scroll.scrollToTop();
    };


    return (
        <View w={"100%"}>
            <View style={headerStyle} zIndex={9}
            // borderBottomWidth={5} borderColor={["#f00", "#0f0", "#00f", "#f0f", "#f90"]}
            >
                <HStack w={"100%"} alignSelf={"center"} justifyContent={"center"} bg={"#fff"}>

                    <Box width={[24, 24, 40, 40]} height={[12, 12, 16, 16]} bg={"#fff"}
                        display={{
                            base: "none",
                            md: "flex"
                        }} />

                    <HStack display={{
                        base: "flex",
                        md: "none"
                    }} alignItems="center" justifyContent="center" space={5} left={-20}>
                        <MenuHamburger />
                        <Link to="/Carrito" style={linkStyle}>
                            <HStack p={2} shadow={3} borderRadius={10} bg={"#449bab"} >

                                <Center>

                                    <TiShoppingCart color="#fff" size={24} />


                                </Center>


                                {carritoCantidad > 0 ?
                                    <Center>
                                        <Center bgColor={"amber.400"} size={[4, 4, 4, 4]} mx={[1, 1, 2, 2]} p={1} borderColor={"muted.300"} borderWidth={1} borderRadius={100}>
                                            <Text bold fontSize={["xs", "sm", "md", "lg"]}>{carritoCantidad}</Text>
                                        </Center>
                                    </Center>
                                    :
                                    null}

                            </HStack>
                        </Link>

                    </HStack>

                    <Center bg="#fff" justifyContent="center" py={2}  >
                        <Link to={"/"} onClick={handleClick}>
                            <Image alignSelf={"center"} source={{
                                uri: "https://createtours.com.mx/pictures/logo-create.png"
                            }} alt="Alternate Text" width={[32, 32, 48, 48]} height={[20, 20, 24, 24]} resizeMode="contain" />
                        </Link>
                    </Center>

                    <Pressable onPress={handlePressTurismo} alignSelf={"center"}>
                        <Image source={{
                            uri: "https://createtours.com.mx/pictures/SEDETUR.png"
                        }} alt="Alternate Text" width={[24, 24, 40, 56]} height={[12, 12, 16, 24]} resizeMode="contain" />
                    </Pressable>
                </HStack>


                {/* STACK de menu */}
                <Stack w={"100%"} direction={"row"}
                    justifyContent={"center"} alignSelf={"center"} bg={"#fff"} alignItems="center"
                    pb={2}
                    display={{
                        base: "none",
                        md: "flex"
                    }}
                >
                    <HStack justifyContent={["center", "center", "flex-end", "flex-end"]}  >
                        <CustomLink to="/" text={t("menu.inicio")} />
                        <CustomLink to="/Tours" text="Tours" />
                        <CustomLink to="/Blog" text="Blog" />
                        <CustomLink to="/Nosotros" text={t("menu.Nosotros")} />
                    </HStack>

                    {/* STACK de menu */}
                    <HStack justifyContent={"center"} alignItems="center"  >
                        <CustomLink to="/Contacto" text={t("menu.Contacto")} />
                        <CustomLink to="/FAQ" text="FAQ" />
                        {/* Boton carrito */}
                        <Link to="/Carrito" style={linkStyle}>
                            <HStack p={1} shadow={3} borderRadius={10} mt={1} borderColor={"muted.300"} borderWidth={1} bg={"#449bab"} justifyContent="center" alignItems="center" >

                                <Center>
                                    <IconContext.Provider value={{ color: "#eeeeee", size: "1.6em" }}>
                                        <TiShoppingCart />
                                    </IconContext.Provider>
                                </Center>


                                {carritoCantidad > 0 ?

                                    <Center bgColor={"amber.400"} size={4} mx={[1, 1, 2, 2]} p={2} borderColor={"muted.300"} borderWidth={1} borderRadius={100}>
                                        <Text bold fontSize="xs">{carritoCantidad}</Text>
                                    </Center>

                                    :
                                    null}
                            </HStack>
                        </Link>
                    </HStack>

                </Stack>

            </View>

            <Outlet />
        </View >
    )
};

export default Header;